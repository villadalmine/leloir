# Leloir CRDs

This directory contains the Kubernetes Custom Resource Definitions (CRDs) for Leloir,
plus sample configurations and Helm values profiles.

## Install all CRDs

```bash
# Apply all CRDs to your cluster
kubectl apply -k ./crds

# Verify
kubectl get crds | grep leloir.dev
```

## CRD reference

| CRD | Kind | Purpose | Required from |
|-----|------|---------|---------------|
| `tenants.leloir.dev` | `Tenant` | Tenant definition + namespace mapping | M2 |
| `agentregistrations.leloir.dev` | `AgentRegistration` | Register an AI agent | M1 |
| `alertroutes.leloir.dev` | `AlertRoute` | Route alerts → agent + tools + notifications | M1 |
| `mcpservers.leloir.dev` | `MCPServer` | Register an MCP tool source | M1 |
| `notificationchannels.leloir.dev` | `NotificationChannel` | Teams/Slack/Telegram config | M1 |
| `approvalpolicies.leloir.dev` | `ApprovalPolicy` | HITL rules for tools + A2A | M4 |
| `tenantbudgets.leloir.dev` | `TenantBudget` | LLM cost caps per tenant | M3 |
| `skillsources.leloir.dev` | `SkillSource` | Runbook/skill repo registration | M2 |

## Sample configuration

`sample-db-incident-response.yaml` contains a full end-to-end example:
a Tenant + HolmesGPT registration + Prometheus MCP + Teams notification + Skills + AlertRoute.
Also includes a commented-out memory integration example (MemPalace / Zep via MCPServer).

Apply it to a test namespace:

```bash
kubectl create namespace team-alpha
kubectl apply -f sample-db-incident-response.yaml
```

## Helm profiles

The `helm-profiles/` directory contains values presets for the Helm chart:

```bash
# Corporate deployment (Azure AD, Vault, strict audit, mTLS)
helm install leloir oci://ghcr.io/leloir/charts/leloir \
  -f crds/helm-profiles/corporate.yaml \
  -f my-overrides.yaml

# Local dev deployment (Anthropic, Dex, relaxed settings)
helm install leloir oci://ghcr.io/leloir/charts/leloir \
  -f crds/helm-profiles/local.yaml \
  --set llmGateway.providers[0].apiKey=$ANTHROPIC_API_KEY
```

See [docs/configuration.md](../docs/configuration.md) for the full values reference.
